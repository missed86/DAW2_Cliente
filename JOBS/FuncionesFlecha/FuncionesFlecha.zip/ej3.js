/*

Hacer una función que convierta de grados centígrados a Farenheit.

*/

const centígrados2farenheit = (grados) => (grados * 9 / 5) + 32

console.log(centígrados2farenheit(10))