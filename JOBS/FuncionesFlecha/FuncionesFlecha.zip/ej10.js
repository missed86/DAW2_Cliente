/*

Hacer una función que calcule el tiempo necesario para que un automóvil que se mueve
con una velocidad de 73000 km/h recorra una distancia de 120 km. (TIEMPO = d/v).

*/

const tiempo = (distancia, velocidad) => distancia/velocidad

console.log(tiempo(120, 73), "horas")