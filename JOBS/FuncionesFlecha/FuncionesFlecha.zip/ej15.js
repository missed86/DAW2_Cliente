/*

Crea una función que reciba un texto y lo devuelva al revés.

*/

const reverse = (text) => text.split("").reverse().join("")

console.log(reverse("Hola mundo"))